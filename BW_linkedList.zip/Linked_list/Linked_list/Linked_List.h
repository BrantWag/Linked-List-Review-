#pragma once
#include "stdafx.h"
#include <memory>
#include <iostream>

using namespace std;
// Templated class used to create a generic class
template <typename blahBlah>
class Node
{
private:
	blahBlah data;
	shared_ptr <Node<blahBlah>>newNode = nullptr;
	shared_ptr <Node<blahBlah>>lastNode = nullptr


public:
	// Constructors 
	Node() 
	{
		data = NULL;
	}
	Node(blahBlah T) 
	{
		date = T;
	}
	Node(blahBlah T, shared_ptr<Node> first, shared_ptr<Node> last) 
	{
		data = T;
		newNode = first;
		lastNode = last;

	}
	//Doconstruct
	~Node() 
	{
		//set new and last node to null
	}
	//get data from node
	blahBlah getData()
	{
		return data;
	}
	//change data
	void changedata(blahBlah X)
	{
		data = X;
	}
	//next node in list 
	shared_ptr<Node> Next()
	{

	}
	//set node in list 
	void Set(shared_ptr<Node> Y)
	{

	}
	//get last node in list
	shared_ptr<Node> getlast()
	{
		//return 
	}
	//set last node in list
	void set_Last(shared_ptr<Node> Z)
	{

	}
};
// Templated class used to create a generic class
template <typename blahBlah>
class LinkedList 
{
private:
	shared_ptr<Node<blahBlah>> one = nullptr;
	shared_ptr<Node<blahBlah>> two = nullptr;
public:
	//construct
	LinkedList()
	{
		//create head, set value etc
		//create tail, set value etc
	}
	//find data in list thru looping list and comparing, report if found or not 
	shared_ptr<Node<blahBlah>> find(blahBlah finddata)
	{

	}
	//insert node into list 
	void Insert(blahBlah X) 
	{
		//create new node
	}
	//delete node be removing pointers and assigning new and last node to eachother
	void Delete(blahBlah Y)
	{
		//empty linked list
		//remove node 
		//set node's 
		//delete pointers
	}
	//diplay all data in list
	void displayList() 
	{
		//loop thru all nodes
		//print data
		//set node in list to next node 
	}

};

