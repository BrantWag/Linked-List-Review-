//Brant Wagner
//Linked List project 
//project not complete still needs work
//This a rough outline with some functions for a milestone check-in.
#include "stdafx.h"
#include <memory>
#include <string>
#include <iostream>
#include "Linked_List.h"

using namespace std;

int main()
{
	// node test 
	cout << endl << "Node Test: " << endl;
	Node <int> FirstNode(4);
	Node <int> SecondNode(20);
	// first node data 
	// second node data
	system("pause");

	// char node test 
	cout << "Character Node Test:  " << endl;
	Node<char> FirstC_Node('B');
	Node<char> SecondC_Node('W');
	//Get data for first 
	//Get data for second 
	system("pause");

	//linked list test 
	LinkedList<int> LinkedList;

	//Test
	cout << endl << "Node Test: " << endl;
	for (int i = 0; i < 10; i++)
	{
		LinkedList.Insert(i);
	}
	LinkedList.displayList();
	system("pause");

	//find test 
	cout << endl << "Find Node Test: " << endl;
	auto Foundnode = LinkedList.find(11);
	// if found
	if ()
	{

	}
	//if not found
	else
	{
		cout << "Node Not Found" << endl;
		system("pause");
	}

	//delete 
	//delete node
	//displaylist 
	system("pasue");

	return 0;


}